import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class JogoColetaSeletiva extends JFrame implements ActionListener {
    private JLabel label;
    private JButton botaoPapel;
    private JButton botaoPlastico;
    private JButton botaoVidro;
    private JButton botaoMetal;
    private JButton botaoOrganico;
    private JPanel painelBotoes;
    private List<ImageIcon> imagensFundo;
    private JLabel labelFundo;
    private int pontos = 0;
    private int pontuacaoAlvo = 100;
    private HashMap<JButton, String> mapaBotoesLixo;

    public JogoColetaSeletiva() {
        super("Jogo de Coleta Seletiva");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        exibirTelaBoasVindas();
    }

    private void exibirTelaBoasVindas() {
        setSize(500, 400);
        setLayout(new BorderLayout());

        JPanel painelBoasVindas = new JPanel(new BorderLayout());

        JLabel labelBoasVindas = new JLabel("Bem-vindo ao Jogo de Coleta Seletiva!");
        labelBoasVindas.setHorizontalAlignment(JLabel.CENTER);
        labelBoasVindas.setFont(new Font("Arial", Font.BOLD, 12));
        painelBoasVindas.add(labelBoasVindas, BorderLayout.CENTER);

        JPanel painelNome = new JPanel(new FlowLayout());

        JLabel labelNome = new JLabel("Digite seu nome:");
        JTextField textFieldNome = new JTextField(20);
        JButton botaoIniciar = new JButton("Iniciar");

        painelNome.add(labelNome);
        painelNome.add(textFieldNome);
        painelNome.add(botaoIniciar);

        botaoIniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textFieldNome.getText();
                if (nome.isEmpty()) {
                    JOptionPane.showMessageDialog(JogoColetaSeletiva.this, "Por favor, insira um nome antes de iniciar o jogo.");
                } else {
                    exibirTelaRegras(nome);
                }
            }
        });

        // Personalização: Cor de fundo do painel de boas-vindas
        painelBoasVindas.setBackground(Color.LIGHT_GRAY);

        // Personalização: Cor e estilo do texto de boas-vindas
        labelBoasVindas.setForeground(Color.BLUE);
        labelBoasVindas.setFont(new Font("Arial", Font.BOLD, 24));

        // Personalização: Cor e estilo do label "Digite seu nome"
        labelNome.setForeground(Color.DARK_GRAY);
        labelNome.setFont(new Font("Arial", Font.PLAIN, 14));

        // Personalização: Cor do botão "Iniciar"
        botaoIniciar.setBackground(Color.GREEN);
        botaoIniciar.setForeground(Color.WHITE);
        botaoIniciar.setFont(new Font("Arial", Font.BOLD, 16));

        add(painelBoasVindas, BorderLayout.CENTER);
        add(painelNome, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void exibirTelaRegras(String nome) {
        getContentPane().removeAll();
        getContentPane().repaint();

        setSize(500, 400);
        setLayout(new BorderLayout());

        JPanel painelRegras = new JPanel(new BorderLayout());

        JLabel labelRegras = new JLabel("Regras do Jogo de Coleta Seletiva");
        labelRegras.setHorizontalAlignment(JLabel.CENTER);
        labelRegras.setFont(new Font("Arial", Font.BOLD, 16));
        painelRegras.add(labelRegras, BorderLayout.NORTH);

        JTextArea textAreaRegras = new JTextArea();
        textAreaRegras.setText("Este é um jogo de coleta seletiva onde você precisa identificar o tipo de lixo exibido na tela e clicar no botão correspondente.\n\n" +
                "Baseado na necessidade de descartar corretamente os tipos de lixo para que sejam reaproveitados ou tomem seu devido caminho para alguma outra solução, desenvolvemos essa simulação onde utilizamos certa demanda de lixo de uma grande metrópole para mostrar como deveria ser feito corretamente o descarte.\n\n" +
                "Você ganhará 10 pontos para cada resposta correta e perderá 5 pontos para cada resposta incorreta.\n\n" +
                "Clique no botão 'Iniciar Jogo' para começar!\n\n" +
                "Boa sorte, " + nome + "!");
        textAreaRegras.setFont(new Font("Arial", Font.PLAIN, 14));
        textAreaRegras.setEditable(false);
        textAreaRegras.setLineWrap(true);
        textAreaRegras.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(textAreaRegras);
        painelRegras.add(scrollPane, BorderLayout.CENTER);

        JButton botaoIniciarJogo = new JButton("Iniciar Jogo");
        botaoIniciarJogo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirTelaJogo(nome);
            }
        });

        JPanel painelBotao = new JPanel(new FlowLayout());
        painelBotao.add(botaoIniciarJogo);
        painelRegras.add(painelBotao, BorderLayout.SOUTH);

        add(painelRegras, BorderLayout.CENTER);

        setVisible(true);

    }

    private void exibirTelaJogo(String nome) {
        getContentPane().removeAll();
        getContentPane().repaint();

        iniciarJogo();

        JOptionPane.showMessageDialog(this, "Olá " + nome + "! Vamos começar o jogo!");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton botaoClicado = (JButton) e.getSource();
        String tipoLixo = mapaBotoesLixo.get(botaoClicado);
        String tipoLixoAtual = obterTipoLixoAtual();

        if (tipoLixo.equals(tipoLixoAtual)) {
            pontos += 10; // Pontuação aumenta em 10 pontos para respostas corretas
            JOptionPane.showMessageDialog(this, "Resposta correta! Você ganhou 10 pontos.");
        } else {
            pontos -= 5; // Pontuação diminui em 5 pontos para respostas incorretas
            JOptionPane.showMessageDialog(this, "Resposta incorreta! Você perdeu 5 pontos.");
        }

        label.setText("Pontuação: " + pontos);
        definirImagemFundo();

        if (pontos >= pontuacaoAlvo) {
            JOptionPane.showMessageDialog(this, "Parabéns! Você alcançou a pontuação-alvo de " + pontuacaoAlvo + " pontos. Você venceu o jogo!");
            reiniciarJogo();
        }
    }

    private void reiniciarJogo() {
        pontos = 0;
        label.setText("Pontuação: " + pontos);
        definirImagemFundo();
    }

    private void iniciarJogo() {
        setSize(500, 400);
        setLayout(new BorderLayout());

        JPanel painelPontuacao = new JPanel();
        label = new JLabel("Pontuação: 0");
        painelPontuacao.add(label);

        painelBotoes = new JPanel(new GridLayout(2, 3));

        botaoPapel = new JButton("Papel");
        botaoPlastico = new JButton("Plástico");
        botaoVidro = new JButton("Vidro");
        botaoMetal = new JButton("Metal");
        botaoOrganico = new JButton("Orgânico");

        botaoPapel.setBackground(Color.BLUE);
        botaoPlastico.setBackground(Color.RED);
        botaoVidro.setBackground(Color.GREEN);
        botaoMetal.setBackground(Color.YELLOW);
        botaoOrganico.setBackground(Color.ORANGE);

        painelBotoes.add(botaoPapel);
        painelBotoes.add(botaoPlastico);
        painelBotoes.add(botaoVidro);
        painelBotoes.add(botaoMetal);
        painelBotoes.add(botaoOrganico);

        botaoPapel.addActionListener(this);
        botaoPlastico.addActionListener(this);
        botaoVidro.addActionListener(this);
        botaoMetal.addActionListener(this);
        botaoOrganico.addActionListener(this);

        imagensFundo = new ArrayList<>();
        imagensFundo.add(new ImageIcon("C:\\Users\\user\\IdeaProjects\\JogoColetaSeletiva.java\\trabalho\\metal.png"));
        imagensFundo.add(new ImageIcon("C:\\Users\\user\\IdeaProjects\\JogoColetaSeletiva.java\\trabalho\\vidro.png"));
        imagensFundo.add(new ImageIcon("C:\\Users\\user\\IdeaProjects\\JogoColetaSeletiva.java\\trabalho\\papel.png"));
        imagensFundo.add(new ImageIcon("C:\\Users\\user\\IdeaProjects\\JogoColetaSeletiva.java\\trabalho\\organico.png"));
        imagensFundo.add(new ImageIcon("C:\\Users\\user\\IdeaProjects\\JogoColetaSeletiva.java\\trabalho\\plastico.png"));


        labelFundo = new JLabel();
        definirImagemFundo();

        add(painelPontuacao, BorderLayout.NORTH);
        add(painelBotoes, BorderLayout.CENTER);
        add(labelFundo, BorderLayout.SOUTH);

        mapaBotoesLixo = new HashMap<>();
        mapaBotoesLixo.put(botaoPapel, "papel");
        mapaBotoesLixo.put(botaoPlastico, "plastico");
        mapaBotoesLixo.put(botaoVidro, "vidro");
        mapaBotoesLixo.put(botaoMetal, "metal");
        mapaBotoesLixo.put(botaoOrganico, "organico");

        setVisible(true);
    }

    private void definirImagemFundo() {
        Random random = new Random();
        int indiceAleatorio = random.nextInt(imagensFundo.size());
        ImageIcon imagemAleatoria = imagensFundo.get(indiceAleatorio);
        labelFundo.setIcon(imagemAleatoria);
    }

    private String obterTipoLixoAtual() {
        ImageIcon imagemAtual = (ImageIcon) labelFundo.getIcon();
        if (imagemAtual != null) {
            String nomeImagem = imagemAtual.getDescription();
            if (nomeImagem.contains("papel")) {
                return "papel";
            } else if (nomeImagem.contains("plastico")) {
                return "plastico";
            } else if (nomeImagem.contains("vidro")) {
                return "vidro";
            } else if (nomeImagem.contains("metal")) {
                return "metal";
            } else if (nomeImagem.contains("organico")) {
                return "organico";
            }
        }
        return "";
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new JogoColetaSeletiva();
            }
        });
    }
}
